THROW. — CHROMEBOOK EDITION (NO INSTALLS)
======================================

WHAT YOU NEED
- A Chromebook, Chrome, internet connection, and this HTML file.
- Each player must have their own copy of the SAME Chromebook Edition HTML.
- You do NOT need Node.js, Linux mode, Chrome extensions, or any app installation.

PLAY ONLINE
1. Download THROW_Chromebook_Online.html.
2. In Chrome, press Ctrl+O, select the downloaded HTML file and open it.
   (Or find it in Files > Downloads and double-click the HTML file.)
3. Host clicks Play > Create a room > enters their nickname.
4. Share the 5-character lobby code with friends. Everyone opens the HTML
   and chooses Join a room, enters the code and their nickname.
5. Host sees players, clicks Start, and everyone gets a 3-second timer.
6. Every player earns +1 per person they beat and -1 per person they lose to.
7. All players must click Vote to end to display the final leaderboard.
8. Press Enter or Back to home at the end.

HOW IT CONNECTS
- The HTML loads the free PeerJS browser library from a CDN.
- The public PeerJS Cloud service helps browsers connect to each other.
- The game traffic then travels directly between players using WebRTC.
- The HOST'S TAB must remain OPEN and ONLINE; closing it ends the room.
- The service is public and outside our control. Some school Wi-Fi networks
  block peer-to-peer/WebRTC. If blocked, try another permitted network.
- You cannot play online without an internet connection or access to the
  public signaling service. No downloadable HTML can guarantee that alone.
- No separate game server or installation is required on your Chromebook.

TROUBLESHOOTING
- 'Needs internet': Wait a few seconds, check internet or blocked CDNs.
- 'Room not found': Make sure the host is still in the lobby and check code.
- A browser or school network may prevent direct WebRTC connection.
- Use a recent Chrome browser and allow JavaScript; avoid incognito if it
  blocks local HTML permissions.
- Local HTML files are not a public website. To share the game by web link,
  put this static file on a hosting service; no app install is necessary.

The multiplayer room lives in the host's browser; it is NOT persisted.
Scores and votes are only for the current live match.
